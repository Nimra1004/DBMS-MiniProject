﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject
{
    class Projectgrp
    {

        private DateTime Assignment_Date;

        public DateTime get_Assignment_Date()
        {
            return Assignment_Date;
        }

        public void set_Assignment_Date(DateTime val)
        {
            Assignment_Date = val;
        }
    }
}
