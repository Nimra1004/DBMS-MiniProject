﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject
{
    class ADD_Group
    {
        private DateTime Created_On;

        public DateTime get_created_on()
        {
            return Created_On;
        }

        public void set_created_on(DateTime val)
        {
            Created_On = val;
        }
    }
}
